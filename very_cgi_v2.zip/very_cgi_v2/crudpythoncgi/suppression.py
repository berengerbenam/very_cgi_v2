#!/usr/bin/python3
import pymysql,cgi,cgitb

def database():
    global conn,curseur
    conn=pymysql.connect(host="localhost",user="benam2",passwd="Passer123/",database="banque")
    curseur=conn.cursor()

def suppression(code):
    req="delete from client where code=%s"
    database()
    val=(code,)
    curseur.execute(req,val)
    conn.commit()
    print("Content-Type:text/plain")
    print("")
    print("suppression reussi")

form=cgi.FieldStorage()
code=form.getvalue('code')

suppression(code)

