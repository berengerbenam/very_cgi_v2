#!/usr/bin/python3
import pymysql,cgi,cgitb

def database():
    global conn,curseur
    conn=pymysql.connect(host="localhost",user="benam2",passwd="Passer123/",database="banque")
    curseur=conn.cursor()

def insertion(prenom,nom,code,numcompte,solde):
    req="insert into client(prenom,nom,code,numcompte,solde) values (%s,%s,%s,%s,%s)"
    database()
    val=(prenom,nom,code,numcompte,solde)
    curseur.execute(req,val)
    conn.commit()
    print("Content-Type:text/plain")
    print("")
    print("insertion reussi")

form=cgi.FieldStorage()
prenom=form.getvalue('prenom')
nom=form.getvalue('nom')
code=form.getvalue('code')
numcompte=form.getvalue('numcompte')
solde=form.getvalue('solde')

insertion(prenom,nom,code,numcompte,solde)
