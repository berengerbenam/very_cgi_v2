#!/usr/bin/python3

print("Content-Type: text/plain")
print("")
print("Bonjour les developpeurs, voici notre premier programme cgi")
