#!/usr/bin/python3
import pymysql

def database():
    global conn, curseur
    conn=pymysql.connect(host="localhost",user="benam2",passwd="Passer123/",database="banque")
    curseur = conn.cursor()

def affiche():
    req = "SELECT * FROM client"
    database()
    curseur.execute(req)

    # Print the HTML header with Bootstrap link
    print("Content-Type:text/html")
    print("")
    print("<!DOCTYPE html>")
    print("<html>")
    print("<head>")
    print("<title>Client Data</title>")
    print('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css">')
    print("</head>")
    print("<body>")

    # Print the table with Bootstrap classes
    print('<div class="container">')
    print('<h1 class="text-center">Liste des Clients</h1>')
    print('<table class="table table-bordered table-striped table-hover">')
    print("<tr><td>Prenom</td><td>Nom</td><td>Code</td><td>Numcompte</td><td>Solde</td></tr>")
    for row in curseur.fetchall():
        print(f"<tr><td>{row[1]}</td><td>{row[2]}</td><td>{row[3]}</td><td>{row[4]}</td><td>{row[5]}</td></tr>")
    print("</table>")
    print('</div>')

    # Print the HTML footer
    print("</body>")
    print("</html>")

affiche()
