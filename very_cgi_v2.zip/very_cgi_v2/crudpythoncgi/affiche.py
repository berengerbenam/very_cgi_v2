#!/usr/bin/python3
import pymysql

def database():
    global conn,curseur
    conn=pymysql.connect(host="localhost",user="benam2",passwd="Passer123/",database="banque")
    curseur=conn.cursor()

def affiche():
    req="select * from client"
    database()
    curseur.execute(req)
    print("Content-Type:text/html")
    print("")
    print("<body><table border='1px'><tr><td>Prenom</td><td>Nom</td><td>Code</td><td>Numcompte</td><td>Solde</td></tr>")
    for row in curseur.fetchall():
        print(f"<tr><td>{row[1]}</td><td>{row[2]}</td><td>{row[3]}</td><td>{row[4]}</td><td>{row[5]}</td></tr>")
    print("</table></body>")

affiche()
